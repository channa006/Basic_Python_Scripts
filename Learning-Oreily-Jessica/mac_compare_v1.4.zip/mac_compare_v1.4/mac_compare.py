import re
import os
import xlsxwriter
import xlrd
import sys
import pprint

def fetch_show_int_status(filename, file_opening_mode):
    speed_duplex_list = []
    speed_duplex_dict = {}
    file = open ( filename, file_opening_mode)
    fileread = file.readlines()
    start = 0
    stop = 0
    status = ""
    ios = False
    for line in fileread:
        #re2 = re.search('^\s*[\*|S]\s+(?P<vlan2>\d+)\s+(?P<mac_addr2>[a-z0-9]{4}\.[a-z0-9]{4}\.[a-z0-9]{4})\s+\D+\s+(?P<interface2>.*)', line)
        re2 = re.search('^\s*[\*|S]*\s+(?P<vlan2>\d+)\s+(?P<mac_addr2>[a-z0-9]{4}\.[a-z0-9]{4}\.[a-z0-9]{4})\s+\D+\s+[\d+]*\s+(?P<interface2>.*)', line)
        if bool(re2):
            ios = True
            print ("IOS")
            break
        #print re2
    if ios:
        for line in fileread:
            if re.match("^.*#sh[ow]* int[erfaces]* st[atus]*", line):
                #status += line
                start = 1
            if start == 1:
                if (re.match("^Gi[0-9]*",line) or re.match("^Te[0-9]*",line) or re.match("^Fa[0-9]*",line)):
                    status += line
                    continue
            if (bool(re.match("^.*#sh[ow]* int[erfaces]* st[atus]* | i[n]* connected",line)) and (start == 1)):
                #print (line)
                break
        status = status.split('\n')
        for line in status:
            if line:
                a = re.sub(' +', ' ', line)
                list1 = a.split(' ')
                pprint.pprint(list1)
                port_new = list1[0]
                if list1[-2] == "No":
                    duplex_new = list1[-4]
                    speed_new = list1[-3]
                else:
                    duplex_new = list1[-3]
                    speed_new = list1[-2]
                #print(line)
                #print(duplex_new)
                #print(speed_new)
                speed_duplex_dict = {'port':port_new,
                                     'duplex':duplex_new,
                                     'speed':speed_new
                                     }
                #print (speed_duplex_dict)
            if bool(speed_duplex_dict):
                speed_duplex_list.append(speed_duplex_dict)
    else:
        #print ("Not IOS")
        for line in fileread:
            if re.match("^.*#sh[ow]* int[erfaces]* st[atus]*", line):
                #status += line
                start = 1
            if start == 1:
                if (re.match("^Gi[0-9]*",line) or re.match("^Te[0-9]*",line) or re.match("^Fa[0-9]*",line)):
                    status += line
                    continue
            if (bool(re.match("^.*#sh[ow]* int[erfaces]* st[atus]* | i[n]* connected",line)) and (start == 1)):
                #print (line)
                break
        status = status.split('\n')
        for line in status:
            if line:
                a = re.sub(' +', ' ', line)
                list1 = a.split(' ')
                port_new = list1[0]
                if list1[-2] == "No":
                    duplex_new = list1[-4]
                    speed_new = list1[-3]
                else:
                    duplex_new = list1[-3]
                    speed_new = list1[-2]
                speed_duplex_dict = {'port':port_new,
                                     'duplex':duplex_new,
                                     'speed':speed_new
                                     }
                #print (speed_duplex_dict)
            if bool(speed_duplex_dict):
                speed_duplex_list.append(speed_duplex_dict)
    #print (speed_duplex_list)
    if not speed_duplex_list:
        status = ""
        count = 0
        print ("\n\n\n CAT OS \n\n\n")
        for line in fileread:
            #if re.match("^.*#sh[ow]* po[rt]* st[atus]*", line): #sh[ow]* po[rt]* st[atus]*
            if(re.search("show port status",line)):
                #print line
                start = 1
                count = 1
                print ("started")
                continue
            if start == 1:
                #print (line)
                count = count+1
                if count < 4:
                    continue
                #if  bool(re.match("^\s+[0-9]+[\/][0-9]+.*",line)):
                else:
                    status += line
                    count = count +1
                    #print (line)
                    #print (type (status))
                    #print line.find("(enable) show")
            if (start == 1) and line.find("(enable)") != -1:
                #print line
                break
        #print (status)
        status = status.split('\n')
        for line in status:
            #print line
            if bool(re.match("^\s*(?P<port1>[0-9]+[\/][0-9]+[\/0-9]*)\s+.*\s+\D+\s+[\d+|\D+]\s+(?P<duplex1>[a-z]+[\-]*[a-z]*)\s+(?P<speed1>.*)\s+.*",line)):
                sdd = re.search("^\s*(?P<port1>[0-9]+[\/][0-9]+[\/0-9]*)\s+.*\s+\D+\s+[\d+|\D+]\s+(?P<duplex1>[a-z]+[\-]*[a-z]*)\s+(?P<speed1>.*)\s+.*",line)
                '''speed_duplex_dict = {'port':line[0:9].strip(),
                                     'duplex':line[52:59].strip(),
                                     'speed':line[60:67].strip()
                                     }'''
                speed_duplex_dict = {'port' : sdd.group('port1'),
                                     'duplex' : sdd.group('duplex1'),
                                     'speed' : sdd.group('speed1')
                                     }
                #pprint.pprint(speed_duplex_dict)
            if bool(speed_duplex_dict):
                speed_duplex_list.append(speed_duplex_dict)
    #pprint.pprint(speed_duplex_list)
    return speed_duplex_list

def fetch_arp_entry_list_ios(filename, file_opening_mode):
    file = open ( filename, file_opening_mode)
    fileread = file.readlines()
    start = 0
    stop = 0
    arp = ""
    #print ("Fetching ARP table...\n")
    ''' To seperate the show ip arp section from the input precheck file'''
    for line in fileread:
        if (re.match("^.*#sh[ow]* ip arp", line)) or (re.match("^.*#sh[ow]* arp", line)):
            arp += line
            start = 1
            ''' this uses to see "Internet" value in the column 0 of the arp table'''
        if start == 1:
            if ("Internet" in line) or ("Protocol" in line):
                arp += line
    #to print the section of ARP table
    #print arp
    file.close()
    file = open ("Test2 output.txt", 'w')
    file.write(arp)
    file.close()
    file = open("Test2 output.txt", 'r')
    fileread = file.readlines()
    arp_entry_list = []
    for line in fileread:
        arp_entry_dict = {}
        if bool(re.search('(?:Internet)\s+(?P<ip_address>\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}).*(?P<mac_address>[a-z0-9]{4}\.[a-z0-9]{4}\.[a-z0-9]{4})\s+\D+\s+(?P<interface>.*)', line)):
            arp_entry = re.search('(?:Internet)\s+(?P<ip_address>\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}).*(?P<mac_address>[a-z0-9]{4}\.[a-z0-9]{4}\.[a-z0-9]{4})\s+\D+\s+(?P<interface>.*)', line)
            arp_entry_dict = {'ip_addr': arp_entry.group('ip_address'),'mac_addr': arp_entry.group('mac_address')}
            if bool(arp_entry_dict):
                arp_entry_list.append(arp_entry_dict)
    file.close()
    os.remove("Test2 output.txt")
    #to print the arp_entry list containing 
    #pprint.pprint(arp_entry_list)
    return arp_entry_list

def fetch_arp_entry_list_catos(filename, file_opening_mode):
    file = open ( filename, file_opening_mode)
    fileread = file.readlines()
    start = 0
    stop = 0
    arp = ""
    #print ("Fetching ARP table...\n")
    ''' To seperate the show ip arp section from the input precheck file'''
    for line in fileread:
        #if (re.match("^.*(enable) sh[ow]* ip arp", line)) or (re.match("^.*(enable) sh[ow]* arp", line)):
        if (re.search("show ip arp",line)):
            #if (re.match("^.*#sh[ow]* ip arp", line)) or (re.match("^.*#sh[ow]* arp", line)):
            #print line
            arp += line
            start = 1
            ''' this uses to see "Internet" value in the column 0 of the arp table'''
        if start == 1:
            if ("Internet" in line) or ("Protocol" in line):
                arp += line
    #to print the section of ARP table
    #print arp
    file.close()
    file = open ("Test2 output.txt", 'w')
    file.write(arp)
    file.close()
    file = open("Test2 output.txt", 'r')
    fileread = file.readlines()
    arp_entry_list = []
    for line in fileread:
        arp_entry_dict = {}
        if bool(re.search('(?:Internet)\s+(?P<ip_address>\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}).*(?P<mac_address>[a-z0-9]{4}\.[a-z0-9]{4}\.[a-z0-9]{4})\s+\D+\s+(?P<interface>.*)', line)):
            arp_entry = re.search('(?:Internet)\s+(?P<ip_address>\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}).*(?P<mac_address>[a-z0-9]{4}\.[a-z0-9]{4}\.[a-z0-9]{4})\s+\D+\s+(?P<interface>.*)', line)
            arp_entry_dict = {'ip_addr': arp_entry.group('ip_address'),'mac_addr': arp_entry.group('mac_address')}
            if bool(arp_entry_dict):
                arp_entry_list.append(arp_entry_dict)
    file.close()
    os.remove("Test2 output.txt")
    #to print the arp_entry list containing 
    #pprint.pprint(arp_entry_list)
    return arp_entry_list


def fetch_mac_add_table_ios(filename, file_opening_mode):
    file = open(filename, file_opening_mode)
    f = file.readlines()
    mac = ""
    start = 0
    stop = 0
    device_name = ""
    #print ("Fetching MAC address table...\n")
    for line in f:
        #print line
        if re.match("^.*#sh[ow]* mac[-]*[\s+]*add[ress\-table]*",line):
            device_name=line[:line.find("#sh")]
            #print (device_name)
            #print line
            start = 1
            mac+=line
        if start == 1 and stop != 1:
            #print line
            mac += line
        if ("Total Mac Addresses for this criterion:" in line) or ("Multicast Entries" in line):
            stop = 1
    #print mac
    file2 = open ("Test3 output.txt", 'w')
    file2.write(mac)
    file2.close()
    file.close()
    file = open("Test3 output.txt", 'r')
    f = file.readlines()
    mac_entry_list = []
    for line in f:
        mac_entry_dict = {}
        #re1 = re.search('^\s*(?P<vlan>\d+)\s+(?P<mac_addr>[a-z0-9]{4}\.[a-z0-9]{4}\.[a-z0-9]{4})\s+\D+\s+[\d+]*\s+(?P<interface>.*)', line)
        re1 = re.search('^\s*(?P<vlan>\d+)\s+(?P<mac_addr>[a-z0-9]{4}\.[a-z0-9]{4}\.[a-z0-9]{4})\s+\D+\s+[\D+]*[\d+]*\s+(?P<interface>.*)', line)
        re2 = re.search('^\s*[\*|S]*\s+(?P<vlan2>\d+)\s+(?P<mac_addr2>[a-z0-9]{4}\.[a-z0-9]{4}\.[a-z0-9]{4})\s+\D+\s+[\d+]*\s+(?P<interface2>.*)', line)
        re3 = re.search('^(?P<vlan>\d+)\s+(?P<mac_addr>[a-z0-9]{4}\.[a-z0-9]{4}\.[a-z0-9]{4})\s+\D+\s+[\D+]*[\d+]*\s+(?P<interface>.*)', line)
        #re3 = re.search('^\s+[R]\s+(?P<vlan3>\d+)\s+(?P<mac_addr3>[a-z0-9]{4}\.[a-z0-9]{4}\.[a-z0-9]{4})\s+\D+\s+\d+\s+(?P<interface3>.*)', line)
        #re4 = re.search('^\s+[S]\s+(?P<vlan2>\d+)\s+(?P<mac_addr2>[a-z0-9]{4}\.[a-z0-9]{4}\.[a-z0-9]{4})\s+\D+\s+(?P<interface2>.*)', line)
        if bool(re1):
            #print("entered re1 ")
            mac_entry = re1
            #print mac_entry.group('interface')
            #print line
            a1 = re.sub(' +', ' ', line)
            list1 = a1.split(' ')
            if list1[0] == '' :
                list1.remove('')
            #pprint.pprint(list1)
            vlan_new = list1[0]
            mac_addr_new = list1[1]
            if(list1[-1] == '\n'):
                interface_new = list1[-2]
            else:
                interface_new = list1[-1]
            #pprint.pprint(list1)
            mac_entry_dict = {'vlan': vlan_new,
                              'mac_addr': mac_addr_new,
                              'interface': interface_new}
            if bool(mac_entry_dict):
                mac_entry_list.append(mac_entry_dict)
        
        elif bool(re2):
            #print("entered re2")
            #print line
            #print ("mac add table is ios ")
            mac_entry = re2
            #print mac_entry.group('interface2')
            line1 = line.strip("\n")
            a1 = re.sub(' +', ' ', line1)
            list1 = a1.split(' ')
            vlan_new = list1[1]
            mac_addr_new = list1[2]
            if(list1[-1] == '\n'):
                interface_new = list1[-2]
            else:
                interface_new = list1[-1]
            #pprint.pprint(list1)
            mac_entry_dict = {'vlan': vlan_new,
                              'mac_addr': mac_addr_new,
                              'interface': interface_new}
            if bool(mac_entry_dict):
                mac_entry_list.append(mac_entry_dict)
        '''else:
            mac_entry = re3
            #print mac_entry.group('interface')
            print line
            a1 = re.sub(' +', ' ', line)
            list1 = a1.split(' ')
            vlan_new = list1[1]
            mac_addr_new = list1[2]
            if(list1[-1] == '\n'):
                interface_new = list1[-2]
            else:
                interface_new = list1[-1]
            #pprint.pprint(list1)
            mac_entry_dict = {'vlan': vlan_new,
                              'mac_addr': mac_addr_new,
                              'interface': interface_new}
            if bool(mac_entry_dict):
                mac_entry_list.append(mac_entry_dict)'''
        '''a1 = re.sub(' +', ' ', line)
        list2 = a1.split(' ')
        pprint.pprint(list2)
        vlan_new = list2[0]
        mac_addr_new = list2[1]
        interface_new = list2[-1]
        mac_entry_dict = {'vlan': vlan_new,
                              'mac_addr': mac_addr_new,
                              'interface': interface_new}
        if bool(mac_entry_dict):
                mac_entry_list.append(mac_entry_dict)'''
    file.close()
    os.remove("Test3 output.txt")
    return mac_entry_list, device_name

def fetch_mac_add_table_catos(filename, file_opening_mode):
    file = open(filename, file_opening_mode)
    f = file.readlines()
    mac = ""
    start = 0
    stop = 0
    device_name = ""
    for line in f:
        #if re.match("^.* (enable) show cam dynamic.*",line):
        if re.search("show cam dynamic",line):
            print "enterd cam table searching"
            device_name=line[:line.find("(enable) sh")]
            start = 1
            mac+=line
        if start == 1 and stop != 1:
            mac += line
        if ("Total Matching CAM Entries Displayed" in line) or ("Multicast Entries" in line):
            stop = 1
    #print mac
    file2 = open ("Test3 output.txt", 'w')
    file2.write(mac)
    file2.close()
    file.close()
    file = open("Test3 output.txt", 'r')
    f = file.readlines()
    mac_entry_list = []
    for line in f:
        mac_entry_dict = {}
        if bool(re.search('^(?P<vlan>\d+)\s+(?P<mac_addr>[a-z0-9]{2}\-[a-z0-9]{2}\-[a-z0-9]{2}\-[a-z0-9]{2}-[a-z0-9]{2}\-[a-z0-9]{2})\s+[\D+]*\d*[\D\.]*\s+(?P<interface>.*)', line)):
            mac_entry = re.search('^(?P<vlan>\d+)\s+(?P<mac_addr>[a-z0-9]{2}\-[a-z0-9]{2}\-[a-z0-9]{2}\-[a-z0-9]{2}-[a-z0-9]{2}\-[a-z0-9]{2})\s+[\D+]*\d*[\D\.]*\s+(?P<interface>.*)', line)
            y = mac_entry.group('mac_addr').split("-")
            mac_addr_ios_format = y[0]+y[1]+"."+y[2]+y[3]+"."+y[4]+y[5]
            mac_entry_dict = {'vlan': mac_entry.group('vlan'),
                              'mac_addr': mac_addr_ios_format,
                              'interface': mac_entry.group('interface').split(" ")[0]}
            if bool(mac_entry_dict):
                mac_entry_list.append(mac_entry_dict)
    #print (mac_entry_list)
    file.close()
    os.remove("Test3 output.txt")
    return mac_entry_list, device_name


def create_worksheet(device_name):
    workbook = xlsxwriter.Workbook(device_name+'.xlsx')
    worksheet = workbook.add_worksheet("Mac comparision")
    worksheet.set_column('A:A', 8)
    worksheet.set_column('B:B', 17)
    worksheet.set_column('C:C', 20)
    worksheet.set_column('D:D', 15)
    worksheet.set_column('E:E', 25)
    worksheet.set_column('F:F', 6)
    worksheet.set_column('G:G', 10)
    worksheet.set_column('H:H', 30)
    worksheet.set_column('I:I', 8)
    worksheet.set_column('J:J', 17)
    worksheet.set_column('K:K', 20)
    worksheet.set_column('L:L', 15)
    worksheet.set_column('M:M', 23)
    worksheet.set_column('N:N', 6)
    worksheet.set_column('O:O', 10)
    worksheet.set_column('P:P', 30)
    return worksheet, workbook

       
def post_mac_arp_table(post_arp_entry_list,post_mac_entry_list,mac_vendors, speed_duplex,device_name):
    #print (speed_duplex)
    post_data = []
    post_data_dict = {}
    global oui_org_list
    org1 = ""
    global speed1
    global duplex1
    post_arp_entry_list = list(filter(None,post_arp_entry_list))
    post_mac_entry_list = list(filter(None,post_mac_entry_list))
    for index_1 in range(0,len(post_mac_entry_list)):
        count = 0
        speed1 = ""
        duplex1 = ""
        for index_2 in range(0,len(post_arp_entry_list)):
            count1 = 0
            try:
                if post_mac_entry_list[index_1]['mac_addr'] == post_arp_entry_list[index_2]['mac_addr']:
                    org1 = ""
                    if oui_org_list != []:
                        for n in range(0,len(oui_org_list)):
                            if str(post_mac_entry_list[index_1]['mac_addr'][:7]).strip() == str(oui_org_list[n]['oui']).strip():
                                count1 = 1
                                org1 = oui_org_list[n]['org'].strip()
                    if count1 == 0:
                        for n in range(0,mac_vendors.nrows):
                            if post_mac_entry_list[index_1]['mac_addr'][:7] == mac_vendors.cell(n,0).value.strip():
                                org1 = mac_vendors.cell(n,1).value.strip()
                                oui_org = {'oui':post_mac_entry_list[index_1]['mac_addr'][:7] ,'org':mac_vendors.cell(n,1).value.strip()}
                                count1 = 1
                                oui_org_list.append(oui_org)
                                break
                    if count1 == 0:
                        org1 = "No Vendor Found"
                    j = str(post_mac_entry_list[index_1]['interface'])
                    interface1 = j[0:2] + j[j.find("net")+3:]
                    #print (interface1)
                    for i in range(0,len(speed_duplex)):
                        #print (interface1, str(speed_duplex[i]['port']).strip())
                        if interface1.strip() == str(speed_duplex[i]['port']).strip():
                            speed1 = speed_duplex[i]['speed']
                            duplex1 = speed_duplex[i]['duplex']
                            #print (speed1, duplex1)
                    post_data_dict = {'vlan':int(post_mac_entry_list[index_1]['vlan']),
                                      'mac':post_mac_entry_list[index_1]['mac_addr'],
                                      'port':post_mac_entry_list[index_1]['interface'],
                                      'arp':post_arp_entry_list[index_2]['ip_addr'],
                                      'org':org1,
                                      'speed':speed1,
                                      'duplex':duplex1,
                                      'device_name':device_name,
                                      'appended_data':post_mac_entry_list[index_1]['vlan']+post_mac_entry_list[index_1]['interface']
                                    }
                    post_data.append(post_data_dict)
                    count += 1
                    break
            except NameError as e:
                print ("ARP ENTRY FOUND   Unexpected error:", sys.exc_info()[0])
                print (re.findall("name '(\w+)' is not defined",str(e))[0])
                continue
        count1 = 0
        if count == 0:
            try:
                if oui_org_list != []:
                    for n in range(0,len(oui_org_list)):
                        if str(post_mac_entry_list[index_1]['mac_addr'][:7]).strip() == str(oui_org_list[n]['oui']).strip():
                            count1 = 1
                            org1 = oui_org_list[n]['org'].strip()
                if count1 == 0:
                    for n in range(0,mac_vendors.nrows):
                        if post_mac_entry_list[index_1]['mac_addr'][:7] == mac_vendors.cell(n,0).value.strip():
                            count1 = 1
                            org1 = mac_vendors.cell(n,1).value.strip()
                            oui_org = {'oui':post_mac_entry_list[index_1]['mac_addr'][:7] ,'org':mac_vendors.cell(n,1).value.strip()}
                            oui_org_list.append(oui_org)
                            break
                if count1 == 0:
                    org1= "No Vendor Found"
                j = str(post_mac_entry_list[index_1]['interface'])
                interface1 = j[0:2] + j[j.find("net")+3:]
                for i in range(0,len(speed_duplex)):
                    #print (interface1, str(speed_duplex[i]['port']).strip())
                    if interface1.strip() == str(speed_duplex[i]['port']).strip():
                        speed1 = speed_duplex[i]['speed']
                        duplex1 = speed_duplex[i]['duplex']
                post_data_dict = {'vlan':int(post_mac_entry_list[index_1]['vlan']),
                                  'mac':post_mac_entry_list[index_1]['mac_addr'],
                                  'port':post_mac_entry_list[index_1]['interface'],
                                  'arp':"Not found",
                                  'org':org1,
                                  'speed':speed1,
                                  'duplex':duplex1,
                                  'device_name':device_name,
                                  'appended_data':post_mac_entry_list[index_1]['vlan']+post_mac_entry_list[index_1]['interface']
                                  }
                post_data.append(post_data_dict)
            except NameError as e:
                print ("ARP ENTRY NOT FOUND    Unexpected error:", sys.exc_info()[0])
                print (re.findall("name '(\w+)' is not defined",str(e))[0])
                continue
    return post_data

def find_redundant_interface(pre_data):
    for index_1 in range(0,len(pre_data)):
        #print(pre_data[index_1]["appended_data"])
        pre_data[index_1]["same_port"] = bool(False)
        for index_2 in range(0,len(pre_data)):
            if(index_1 != index_2 and pre_data[index_1]["appended_data"] == pre_data[index_2]["appended_data"]):
                pre_data[index_1]["same_port"] = bool(True)
                break
    #print pre_data[index_1]["same_port"] 
    return pre_data

def find_deleting_nodes(post_data):
    for index_1 in range(0,len(post_data)):
        post_data[index_1]["present"] = bool(False)
    return post_data

def mac_compare(pre_data, post_data, worksheet, format, row, vlan_comp, workbook,format1, vlan_mapping_sheet=None):
    pre_data_len = len(pre_data)
    vlan_map_list = []
    post_data_len = -1
    #pre_data_for_comp = pre_data
    #post_data_for_comp = post_data
    if vlan_comp == 1:
        vlan_sheet = xlrd.open_workbook("VLAN Mapping Sheet.xlsx")
        vlan_sheets = vlan_sheet.sheet_names()
        vlan_mapping_sheet = vlan_sheet.sheet_by_name(vlan_sheets[0])
        for i in range(1,vlan_mapping_sheet.nrows):
            vlan_dict = {'old_vlan':int(vlan_mapping_sheet.cell(i,0).value),
                         'new_vlan':int(vlan_mapping_sheet.cell(i,1).value)
                         }
            vlan_map_list.append(vlan_dict)
        #pprint.pprint(vlan_map_list)
    #print("post_data_before_bool")
    #pprint.pprint(post_data)            
    #print("post_data_after_bool")
    #pprint.pprint(post_data)
    #print post_data[0]['present']
    for i in range(0, pre_data_len):
        try:
            #pprint.pprint(pre_data)
            worksheet.write(row, 0, pre_data[i]['vlan'])
            worksheet.write(row, 1, pre_data[i]['mac'])                
            worksheet.write(row, 2, pre_data[i]['port'])
            if pre_data[i]['arp'].strip() == "Not found":
                worksheet.write(row, 3, pre_data[i]['arp'], format)
            else:
                worksheet.write(row, 3, pre_data[i]['arp'])
            if pre_data[i]['org'].strip() == "No Vendor Found":
                worksheet.write(row, 4, pre_data[i]['org'], format)
            else:
                worksheet.write(row, 4, pre_data[i]['org'])
            worksheet.write(row, 5, pre_data[i]['speed'])
            worksheet.write(row, 6, pre_data[i]['duplex'])
            if(pre_data[i]['same_port']==bool(True)):
                worksheet.write(row, 7, pre_data[i]['appended_data'],format)
            else:
                worksheet.write(row, 7, pre_data[i]['appended_data'])
            #pprint.pprint(post_data)
            match_found = 0
            post_data_len = len(post_data)
            for i_2 in range(0, post_data_len):
                if pre_data[i]['mac'].strip() == post_data[i_2]['mac'].strip():
                    #print(pre_data[i]['mac'].strip())
                    #print(post_data[i_2]['mac'].strip())
                    post_data[i_2]['present'] = bool(True)
                    match_found += 1
                    #print post_data[i_2]['mac'].strip()
                    #print post_data[i_2]['present']
                    interface_list = post_data[i_2]['port']
                    #print interface_list
                    for i_3 in range(0,post_data_len):
                        if post_data[i_2]['mac'].strip() == post_data[i_3]['mac'].strip() and i_2 != i_3 :
                            #print "entered the if statment"
                            interface_list = interface_list + ' , ' + post_data[i_3]['port']
                            post_data[i_3]['present'] = bool(True)
                    #print interface_list      
                    #pprint.pprint(post_data[i_2]['present'])
                    #print "row"
                    #print row
                    if vlan_comp == 1:
                        new_vlan = 0
                        for j in range(0,len(vlan_map_list)):
                            if str(pre_data[i]['vlan']).strip() == str(vlan_map_list[j]['old_vlan']).strip():
                                new_vlan = vlan_map_list[j]['new_vlan']
                        if new_vlan == 0:
                            if str(pre_data[i]['vlan']).strip() == str(post_data[i_2]['vlan']).strip():
                                worksheet.write(row, 8, post_data[i_2]['vlan'])
                            else:
                                worksheet.write(row, 8, post_data[i_2]['vlan'],format)
                            '''wrap = workbook.add_format({'text_wrap': True})
                            worksheet.set_column('I:I', 40)
                            worksheet.write(row, 8, str(post_data[i_2]['vlan'])+"\nNot specified in VLAN Mapping sheet",wrap)'''
                        elif new_vlan == post_data[i_2]['vlan']:
                            worksheet.write(row, 8, post_data[i_2]['vlan'])
                        else:
                            worksheet.write(row, 8, post_data[i_2]['vlan'],format)
                    else:
                        if str(pre_data[i]['vlan']).strip() == str(post_data[i_2]['vlan']).strip():
                            worksheet.write(row, 8, post_data[i_2]['vlan'])
                        else:
                            worksheet.write(row, 8, post_data[i_2]['vlan'],format)
                    #speed and duplex comparison for pre device and post device, stripping 'a-' and replacing '10G' if present to '10000' then compare withe the value.
                    pre_duplex_for_comp = pre_data[i]['duplex']
                    post_duplex_for_comp = post_data[i_2]['duplex']
                    #pre_duplex_for_comp= pre_duplex_for_comp.strip('a-')
                    #post_duplex_for_comp= post_duplex_for_comp.strip('a-')
                    #pprint.pprint(pre_data[i])
                    
                    #print(type(pre_data[i]['speed']))
                    pre_speed_for_comp = pre_data[i]['speed']
                    post_speed_for_comp = post_data[i_2]['speed']
                    if(post_speed_for_comp == "10G"):
                        post_speed_for_comp = int("10000")
                    if(pre_speed_for_comp == "10G"):
                        pre_speed_for_comp = int("10000")

                    if(pre_speed_for_comp == ''):
                        #print("enterd if of pre")
                        pre_speed_for_comp = None
                    if(post_speed_for_comp == ''):
                        #print("entered if of post")
                        post_speed_for_comp = None
                    '''print(pre_speed_for_comp)
                    print(type(pre_speed_for_comp))
                    print(post_speed_for_comp)
                    print(type(post_speed_for_comp))
                    if(pre_speed_for_comp == "\n"):
                        print ("pre nothing is there")
                    elif(pre_speed_for_comp == None):
                        print ("None found in pre")'''
                    #speed_comparison - logic correct or not
                    #print pre_speed_for_comp
                    #print post_speed_for_comp
                    #print
                    if (pre_speed_for_comp != None and post_speed_for_comp == None):
                        worksheet.write(row,13,"")
                    elif(pre_speed_for_comp == None and post_speed_for_comp != None):
                        worksheet.write(row,13,post_data[i_2]['speed'],format)
                    elif(pre_speed_for_comp == None and post_speed_for_comp == None):
                         worksheet.write(row,13,"")
                    elif(re.search("a-",pre_speed_for_comp)== None and re.search("a-",post_speed_for_comp) != None ):
                        #if( pre_speed_for_comp == post_speed_for_comp    ):
                        #    worsheet.write(row,13,post_data[i_2]['speed'])
                        #else:
                        worksheet.write(row,13,post_data[i_2]['speed'],format)
                    elif(re.search("a-",pre_speed_for_comp)!= None and re.search("a-",post_speed_for_comp) == None ):
                        worksheet.write(row,13,post_data[i_2]['speed'],format)
                    elif(re.search("a-",pre_speed_for_comp)!= None and re.search("a-",post_speed_for_comp) != None ):
                        pre_speed_for_comp= pre_speed_for_comp.strip('a-')
                        post_speed_for_comp= post_speed_for_comp.strip('a-')
                        if(post_speed_for_comp == "10G"):
                            post_speed_for_comp = int("10000")
                        if(pre_speed_for_comp == "10G"):
                            pre_speed_for_comp = int("10000")
                        if(pre_speed_for_comp != "" and post_speed_for_comp != "" and int(pre_speed_for_comp) < int(post_speed_for_comp) ):
                        #print("entered")
                        #format.set_font_color('green')
                            worksheet.write(row, 13, post_data[i_2]['speed'],format1)
                        elif(pre_speed_for_comp != "" and post_speed_for_comp != ""  and int(pre_speed_for_comp) > int(post_speed_for_comp)):  
                            worksheet.write(row, 13, post_data[i_2]['speed'],format)
                        else:
                            worksheet.write(row, 13, post_data[i_2]['speed'])
                    elif(re.search("a-",pre_speed_for_comp)== None and re.search("a-",post_speed_for_comp) == None):
                        if(pre_speed_for_comp == post_speed_for_comp):
                           worksheet.write(row, 13, post_data[i_2]['speed'])
                        else:
                           worksheet.write(row, 13, post_data[i_2]['speed'],format) 


                   #duplex_comparison - need to be updated
                    if(re.search("a-",pre_duplex_for_comp)== None and re.search("a-",post_duplex_for_comp) != None ):
                        worksheet.write(row,14,post_data[i_2]['duplex'],format)
                    elif(re.search("a-",pre_duplex_for_comp)!= None and re.search("a-",post_duplex_for_comp) == None ):
                        worksheet.write(row,14,post_data[i_2]['duplex'],format)
                    elif(re.search("a-",pre_duplex_for_comp)!= None and re.search("a-",post_duplex_for_comp) != None ):
                        pre_duplex_for_comp= pre_duplex_for_comp.strip('a-')
                        post_duplex_for_comp= post_duplex_for_comp.strip('a-')
                        if(pre_duplex_for_comp != "" and post_duplex_for_comp != "" and (pre_duplex_for_comp) == (post_duplex_for_comp) ):
                        #print("entered")
                        #format.set_font_color('green')
                            worksheet.write(row, 14, post_data[i_2]['duplex'])
                        else:
                            worksheet.write(row, 14, post_data[i_2]['duplex'],format)
                    elif(re.search("a-",pre_duplex_for_comp)== None and re.search("a-",post_duplex_for_comp) == None):
                        if(pre_duplex_for_comp == post_duplex_for_comp):
                           worksheet.write(row, 14, post_data[i_2]['duplex'])
                        else:
                           worksheet.write(row, 14, post_data[i_2]['duplex'],format)
                           
                        '''if(pre_speed_for_comp != "" and post_speed_for_comp != "" and int(pre_speed_for_comp) < int(post_speed_for_comp) ):
                        #print("entered")
                        #format.set_font_color('green')
                        worksheet.write(row, 13, post_data[i_2]['speed'],format1)
                        
                        elif(pre_speed_for_comp != "" and post_speed_for_comp != ""  and int(pre_speed_for_comp) > int(post_speed_for_comp)):  
                            worksheet.write(row, 13, post_data[i_2]['speed'],format)

                    else:
                        worksheet.write(row, 13, post_data[i_2]['speed'])'''

                    worksheet.write(row, 9, post_data[i_2]['mac'])
                    worksheet.write(row, 10, interface_list)
                    format.set_font_color('red') 
                    if post_data[i_2]['arp'].strip() == "Not found":
                        worksheet.write(row, 11, post_data[i_2]['arp'], format)
                    else:
                        worksheet.write(row, 11, post_data[i_2]['arp'])
                    #worksheet.write(row, 13, post_data[i_2]['speed'])
                    #worksheet.write(row, 14, post_data[i_2]['duplex'])
                    if(post_data[i_2]['same_port']==bool(True)):
                        worksheet.write(row, 15, post_data[i_2]['appended_data'],format)
                    else:
                        worksheet.write(row, 15, post_data[i_2]['appended_data'])
                    #del post_data[i_2]
                    post_data[i_2]['present'] = bool(True)
            if match_found == 0:
                worksheet.write(row, 9, "#Missing", format)
            row = row+1
        except KeyError as e:
            print (e)
            print ("Unexpected error in MAC Comparision: ", sys.exc_info()[0])
            continue
    #pprint.pprint(post_data)
    worksheet.write(row, 8, "------------New MAC Addresses----------")
    row += 1
    post_data_len = len(post_data)
    #pprint.pprint(post_data)
    for i in range(0,post_data_len):
        if(post_data[i]['present'] == bool(False)):
            worksheet.write(row, 8, post_data[i]['vlan'])
            worksheet.write(row, 9, post_data[i]['mac'])
            worksheet.write(row, 10, post_data[i]['port'])
            if post_data[i]['arp'] == "Not found":
                worksheet.write(row, 11, post_data[i]['arp'], format)
            else:
                worksheet.write(row, 11, post_data[i]['arp'])
            if post_data[i]['org'] == "No Vendor Found":
                worksheet.write(row, 12, post_data[i]['org'], format)
            else:
                worksheet.write(row, 12, post_data[i]['org'])
                worksheet.write(row, 13, post_data[i]['speed'])
                worksheet.write(row, 14, post_data[i]['duplex'])
            if(post_data[i]['same_port']==bool(False)):
                worksheet.write(row, 15, post_data[i]['appended_data'],format)
            else:
                worksheet.write(row, 15, post_data[i]['appended_data'])
            row += 1  
    
def main():
    print ("Searching for ARP table in Prechecks...\n")

    # ARP_entry_list contain "ip address" and "mac address" in it
    arp_entry_list = fetch_arp_entry_list_ios("Prechecks.txt", 'r')
    #pprint.pprint(arp_entry_list)
    if not arp_entry_list:
        arp_entry_list = fetch_arp_entry_list_catos("Prechecks.txt", 'r')
        print("show ip arp command output not found in prechecks\n")
        #exit(0)
    else:
        print ("ARP table found and parsed succesfully from Prechecks\n")
    #MAC_tale contains vlan, mac address, interface
    print ("Searching for MAC table in Prechecks...\n")
    mac_entry_list, device_name = fetch_mac_add_table_ios("Prechecks.txt", 'r')
    #pprint.pprint(mac_entry_list)
    if not mac_entry_list:
        mac_entry_list, device_name = fetch_mac_add_table_catos("Prechecks.txt", 'r')
        if not mac_entry_list:
            a = input("show mac address-table/show cam dynamic command output not found in Prechecks.txt.\n\nPress <Ctrl+C> to quit")
            exit(0)
        else:
            print ("CAM table found and parsed succesfully from Prechecks\n")
    else:
        print ("MAC table found and parsed succesfully from Prechecks\n")
    print ("Searching for show interface status command in Prechecks...\n")
    #pre_speed_duplex contain duplex,port,speed
    pre_speed_duplex = fetch_show_int_status("Prechecks.txt", 'r')
    #pprint.pprint(pre_speed_duplex)
    if not pre_speed_duplex:
        print("show interface status not found in Prechecks.txt\n")
    else:
        print ("show interface status/show port status command output found in prechecks and parsed succesfully\n")
    print ("Searching fot ARP table in Postchecks...\n")
    post_arp_entry_list = fetch_arp_entry_list_ios("Postchecks.txt", 'r')
    #pprint.pprint(post_arp_entry_list)
    if not post_arp_entry_list:
        print("show ip arp command not found in postchecks\n")
        #exit(0)
    else:
        print ("ARP table found and parsed succesfully from Postchecks\n")
    print ("Searching for MAC/CAM table in Postchecks...\n")
    post_mac_entry_list, device_name1 =fetch_mac_add_table_ios("Postchecks.txt", 'r')
    #pprint.pprint(post_mac_entry_list)    
    if not post_mac_entry_list:
        post_mac_entry_list, device_name1 = fetch_mac_add_table_catos("Postchecks.txt", 'r')
        if not post_mac_entry_list:
            a = input ("show mac address-table command output is missing in Postchecks.txt.\n\nPress <Ctrl+C> to quit")
            exit(0)
        else:
            print ("CAM table found and parsed succesfully from Postchecks\n")
    else:
        print ("MAC table found and parsed succesfully from Postchecks\n")
    post_speed_duplex = fetch_show_int_status("Postchecks.txt", 'r')
    #pprint.pprint(post_speed_duplex)
    if not post_speed_duplex:
        print("show interface status not found in Postchecks.txt.")
    else:
        print ("show interface status/show port status command output found in postchecks and parsed succesfully\n")
    print ("Searching fot ARP table in Postchecks...\n")
    #print device_name
    device_name_list = device_name.split(" ")
    device_name = device_name_list[0].strip(">")
    #print device_name
    device_name1_list = device_name1.split(" ")
    device_name1 = device_name_list[0].strip(">")   
    worksheet,workbook = create_worksheet(device_name+" - "+device_name1)
    global row
    bold_font = workbook.add_format({'bold': True})
    bold_font.set_font_size(14)
    worksheet.write(row, 0, "-----------------------------------------------------Prechecks--------------------------------------------------------",bold_font)
    worksheet.write(row, 8, "---------------------------------------------------Postchecks------------------------------------------------------",bold_font)
    row = row + 1
    worksheet.write(row, 0, "VLAN")
    worksheet.write(row, 1, "MAC Address")
    worksheet.write(row, 2, "Interface")
    worksheet.write(row, 3, "IP Address")
    worksheet.write(row, 4, "Vendor")
    worksheet.write(row, 5, "Speed")
    worksheet.write(row, 6, "Duplex")
    worksheet.write(row, 7, "Appended data")
    
    worksheet.write(row, 8, "New VLAN")
    worksheet.write(row, 9, "MAC Address")
    worksheet.write(row, 10, "New Interface")
    worksheet.write(row, 11, "New IP Address")
    worksheet.write(row, 12, "Vendor for new Macs learned")
    worksheet.write(row, 13, "Speed")
    worksheet.write(row, 14, "Duplex")
    worksheet.write(row, 15, "Appended data")
    row+=1
    format = workbook.add_format({'bold': True, 'font_color': 'red'})
    format1 = workbook.add_format()
    format1.set_font_color('green')
    #print ("Fetching MAC Vendors...\n")
    sheet1 = xlrd.open_workbook("MAC Vendors Database.xlsx")
    sheets = sheet1.sheet_names()
    #pprint.pprint(sheets)
    mac_vendors = sheet1.sheet_by_name(sheets[0])
    print ("Combining APR table, MAC table, Speed/Duplex information and fetching MAC Vendors for Prechecks...\n")
    pre_data = post_mac_arp_table(arp_entry_list, mac_entry_list, mac_vendors, pre_speed_duplex,device_name)
    #pprint.pprint(pre_data)

    '''pre_data_with_device_name = {}
    #print device_name

    pre_data_with_device_name={"device_name" : device_name , "content" : pre_data}
    #pprint.pprint(pre_data_with_device_name)
    '''

    print ("Combining APR table, MAC table, Speed/Duplex information and fetching MAC Vendors for Postchecks...\n")
    post_data = post_mac_arp_table(post_arp_entry_list,post_mac_entry_list,mac_vendors, post_speed_duplex,device_name1)
    #pprint.pprint(post_data)
    
    '''post_data_with_device_name={"device_name" : device_name1 , "content" : post_data}
    #pprint.pprint(post_data_with_device_name["device_name"])'''

    pre_data = find_redundant_interface(pre_data)
    #pprint.pprint(pre_data)
    post_data = find_redundant_interface(post_data)
    #pprint.pprint(post_data)
    post_data=find_deleting_nodes(post_data)
    #pprint.pprint(post_data)
    print ("Comparing MAC addresses from Pre and Post checks...\n")
    vlan_comp = input("Do you have VLAN mapping sheet? [yes/no] :  ").lower().strip()
    #vlan_comp = "yes"
    print vlan_comp
    if vlan_comp == "yes":
        vlan_comp = 1
        vlan_sheet = xlrd.open_workbook("VLAN Mapping Sheet.xlsx")
        vlan_sheets = vlan_sheet.sheet_names()
        vlan_mapping_sheet = vlan_sheet.sheet_by_name(vlan_sheets[0])
        if vlan_mapping_sheet.nrows <= 1:
            print ("VLAN Mapping sheet is empty")
            a = raw_input("Press  \'ctrl + c\'  to quit")
            exit(0)
        #pprint.pprint(pre_data)
        #pprint.pprint(post_data)
        mac_compare(pre_data, post_data, worksheet, format, row, vlan_comp,workbook,format1, vlan_mapping_sheet)
    elif vlan_comp == "no":
        vlan_comp = 0
        mac_compare(pre_data, post_data, worksheet, format, row, vlan_comp,workbook,format1)
    else :
        print ("\nInvalid input. Not comparing VLAN's.")
        vlan_comp = 0
        mac_compare(pre_data, post_data, worksheet, format, row, vlan_comp,workbook,format1)        

    workbook.close()
    #print("\n-----------------------Execution done-----------------------")
    a = raw_input("Press <Enter> to quit")
    

oui_org_list = []
oui_org = {}
row = 0
main()
